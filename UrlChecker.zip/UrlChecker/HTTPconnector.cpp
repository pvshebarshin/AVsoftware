#include "HTTPconnector.h"
#include <QtCore>

HTTPconnector::HTTPconnector(QObject *parent) : QThread(parent)
{
    manager = new QNetworkAccessManager();
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(replyFinished(QNetworkReply*)));
}

HTTPconnector::~HTTPconnector()
{
    delete manager;
    delete timer;
}

void HTTPconnector::run()
{
    qDebug() << "run " << index << *url;

    manager->get(QNetworkRequest(*url));
}

void HTTPconnector::replyFinished(QNetworkReply *reply)
{
//    reply->deleteLater();
    QVariant status_code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute);
    QString status = status_code.toString();
    qDebug() << status << this->index;
    if(url->isNewCode(status)){
        url->newTime();
        url->setCode(status);
        emit addToTable(status, url->getTime(), this->index);
    } else {
        url->setCode(status);
        url->addInterval();
        emit addToTable(status, -1, this->index);
    }
    if(stop)
    {
        timer->stop();
        return;
    } else {
        timer->stop();
        timer->start(interval);
        manager->get(QNetworkRequest(*url));
    }
}
