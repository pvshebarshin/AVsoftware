#ifndef HTTPCONNECTOR_H
#define HTTPCONNECTOR_H

#include "URL.h"

#include <QThread>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QTimer>
#include <QTime>

class HTTPconnector : public QThread
{
    Q_OBJECT
public:
    explicit HTTPconnector(QObject *parent = 0);
    ~HTTPconnector();
    void run();

    URL* url;
    bool stop;
    int index;
    int interval;
    QNetworkAccessManager* manager;
    QTimer* timer;

signals:
//    void httpFinished();
    void addToTable(QString str, int time, int index);

public slots:
    void replyFinished(QNetworkReply* reply);
};

#endif
